<?php

namespace MailSo;

/**
 * @category MailSo
 */
final class Capa
{
	/**
	 * @var bool
	 */
	static $ICONV = true;

	/**
	 * @var bool
	 */
	static $MBSTRING = true;
}
