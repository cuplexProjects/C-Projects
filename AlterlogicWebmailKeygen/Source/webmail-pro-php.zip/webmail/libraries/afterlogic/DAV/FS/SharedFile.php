<?php
namespace afterlogic\DAV\FS;

class SharedFile extends File{
	
	protected $linkPath;

	protected $sharedItem;
    
	protected $isLink;

	public function __construct(\Sabre\DAV\Auth\Plugin $authPlugin, $path, $sharedItem, $isLink = false) {

		parent::__construct($authPlugin, $sharedItem->getPath());

		$this->sharedItem = $sharedItem;
		$this->linkPath = $path;
		$this->isLink = $isLink;
		
    }
	
	public function getRootPath($iType = \EFileStorageType::Private_) {

		return $this->path;

    }

	public function getPath() {

		return $this->linkPath;

    }
	
	public function getName() {

        if ($this->isLink)
		{
			return $this->sharedItem->getName();
		}
		else 
		{
	        list(, $name)  = \Sabre\DAV\URLUtil::splitPath($this->linkPath);
		    return $name;
		}

    }

	public function getOwner() {

        return $this->sharedItem->getOwner();

    }

	public function getAccess() {

        return $this->sharedItem->getAccess();

    }

	public function getLink() {

        return $this->sharedItem->getLink();

    }

	public function isDirectory() {

        return $this->sharedItem->isDirectory();

    }

	public function getDirectory() {
		
		return new Directory($this->authPlugin, dirname($this->path));
		
	}
	
    /**
     * Returns the data
     *
     * @return resource
     */
    public function get() {

        \CApi::Log($this->path, \ELogLevel::Full, 'file-');
		return fopen($this->path,'r');

    }	
	
	public function delete() {

        parent::delete();
		
		$oDirectory = $this->getDirectory();
		$oDirectory->updateQuota();

    }
}

