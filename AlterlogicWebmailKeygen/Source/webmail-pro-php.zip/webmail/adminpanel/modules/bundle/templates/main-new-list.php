<table class="wm_contacts_view">
	<tr>
		<td class="wm_field_title">
			<?php echo CApi::I18N('ADMIN_PANEL/LISTS_USERNAME'); ?>:
		</td>
		<td class="wm_field_value">
			<input name="hiddenDomainId" type="hidden" id="hiddenDomainId" value="<?php $this->Data->PrintInputValue('hiddenDomainId'); ?>" />
			
			<input name="txtMailingListUserName" type="text" id="txtMailingListUserName" class="wm_input"
				style="width: 150px" maxlength="50" value="" />
			
			<span style="font-size: large;">@<?php $this->Data->PrintValue('txtNewMailingListDomain'); ?></span>
		</td>
	</tr>
</table>