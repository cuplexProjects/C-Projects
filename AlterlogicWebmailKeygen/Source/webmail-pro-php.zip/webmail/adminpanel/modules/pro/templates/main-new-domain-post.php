<table class="wm_contacts_view">
	<tr>
		<td>
			<input name="chOverrideSettings" type="checkbox" id="chOverrideSettings" class="wm_checkbox" value="1" checked="checked" />
			<label for="chOverrideSettings" id="chOverrideSettings_label"><?php echo CApi::I18N('ADMIN_PANEL/DOMAINS_DEFAULT_OVERRIDE'); ?></label>
		</td>
	</tr>
</table>