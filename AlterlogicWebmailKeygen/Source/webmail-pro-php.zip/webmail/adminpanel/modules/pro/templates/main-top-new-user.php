<h1><?php echo CApi::I18N('ADMIN_PANEL/USERS_CREATE_TITLE'); ?></h1>
