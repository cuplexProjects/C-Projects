<?php

/*
 * Copyright (C) 2002-2013 AfterLogic Corp. (www.afterlogic.com)
 * Distributed under the terms of the license described in LICENSE
 *
 */

class CProPostAction extends ap_CoreModuleHelper
{
	public function CommonTenant()
	{
		if ($this->oAdminPanel->IsTenantAuthType())
		{
			$oTenant = $this->oModule->GetTenantAdminObject();
			/* @var $oTenant CTenant */
			if ($oTenant)
			{
				if ($oTenant->AllowChangeAdminEmail)
				{
					$oTenant->Email = CPost::Get('txtTenantAdminEmail');
				}

				if ($oTenant->AllowChangeAdminPassword && API_DUMMY !== CPost::Get('txtTenantPassword') && 0 < strlen(trim(CPost::Get('txtTenantPassword'))))
				{
					$oTenant->SetPassword(CPost::Get('txtTenantPassword'));
				}

				if ($oTenant && $this->oModule->UpdateTenantAdminObject($oTenant))
				{
					$this->LastMessage = AP_LANG_SAVESUCCESSFUL;
					$this->LastError = '';
				}
				else
				{
					$this->LastMessage = '';
					$this->LastError = AP_LANG_SAVEUNSUCCESSFUL;
				}
			}
		}
	}

	public function CommonHelpdesk()
	{
		$oApiCapa = CApi::Manager('capability');
		if ($oApiCapa && $oApiCapa->IsHelpdeskSupported() && (
			$this->oAdminPanel->IsTenantAuthType() ||
			($this->oAdminPanel->IsSuperAdminAuthType() && !$oApiCapa->IsTenantsSupported())
		))
		{
			$oTenant = /* @var $oTenant CTenant */  $this->oModule->GetTenantAdminObject();
			if ($oTenant && $oTenant->IsHelpdeskSupported())
			{
				$oTenant->HelpdeskAdminEmailAccount = CPost::Get('txtAdminEmailAccount');
				$oTenant->HelpdeskAllowFetcher = CPost::GetCheckBox('chHelpdeskAllowFetcher');
				$oTenant->HelpdeskClientIframeUrl = CPost::Get('txtClientIframeUrl');
				$oTenant->HelpdeskAgentIframeUrl = CPost::Get('txtAgentIframeUrl');
				$oTenant->HelpdeskSiteName = CPost::Get('txtHelpdeskSiteName');
				$oTenant->HelpdeskStyleAllow = CPost::Get('chHelpdeskStyleAllow');
				$oTenant->HelpdeskStyleImage = CPost::Get('txtHelpdeskStyleImage');
				$oTenant->SetHelpdeskStyleText(CPost::Get('txtHelpdeskStyleText'));

				$oTenant->HelpdeskFacebookAllow = CPost::Get('chHelpdeskFacebookAllow');
				$oTenant->HelpdeskFacebookId = CPost::Get('txtHelpdeskFacebookId');
				$oTenant->HelpdeskFacebookSecret = CPost::Get('txtHelpdeskFacebookSecret');
				$oTenant->HelpdeskGoogleAllow = CPost::Get('chHelpdeskGoogleAllow');
				$oTenant->HelpdeskGoogleId = CPost::Get('txtHelpdeskGoogleId');
				$oTenant->HelpdeskGoogleSecret = CPost::Get('txtHelpdeskGoogleSecret');
				$oTenant->HelpdeskTwitterAllow = CPost::Get('chHelpdeskTwitterAllow');
				$oTenant->HelpdeskTwitterId = CPost::Get('txtHelpdeskTwitterId');
				$oTenant->HelpdeskTwitterSecret = CPost::Get('txtHelpdeskTwitterSecret');
			}

			if ($oTenant && $oTenant->IsHelpdeskSupported() && $this->oModule->UpdateTenantAdminObject($oTenant))
			{
				$this->LastMessage = AP_LANG_SAVESUCCESSFUL;
				$this->LastError = '';
			}
			else
			{
				$this->LastMessage = '';
				$this->LastError = AP_LANG_SAVEUNSUCCESSFUL;
			}
		}
	}

	public function CommonSip()
	{
		$oApiCapa = CApi::Manager('capability');
		/* @var $oApiCapa CApiCapabilityManager */

		if ($oApiCapa && $oApiCapa->IsSipSupported())
		{
			$oTenant = /* @var $oTenant CTenant */  $this->oModule->GetTenantAdminObject();
			if ($oTenant && $oTenant->IsSipSupported())
			{
				$oTenant->SipAllow = CPost::GetCheckBox('chAllowSip');
				$oTenant->SipRealm = CPost::Get('txtSipRealm');
				$oTenant->SipWebsocketProxyUrl = CPost::Get('txtSipWebsocketProxyUrl');
				$oTenant->SipOutboundProxyUrl = CPost::Get('txtSipOutboundProxyUrl');
				$oTenant->SipCallerID = CPost::Get('txtSipCallerID');
			}

			if ($oTenant && $oTenant->IsSipSupported() && $this->oModule->UpdateTenantAdminObject($oTenant))
			{
				$this->LastMessage = AP_LANG_SAVESUCCESSFUL;
				$this->LastError = '';
			}
			else
			{
				$this->LastMessage = '';
				$this->LastError = AP_LANG_SAVEUNSUCCESSFUL;
			}
		}
	}
	
	public function CommonTwilio()
	{
		$oApiCapa = CApi::Manager('capability');
		/* @var $oApiCapa CApiCapabilityManager */

		if ($oApiCapa && $oApiCapa->IsTwilioSupported())
		{
			$oTenant = /* @var $oTenant CTenant */  $this->oModule->GetTenantAdminObject();
			if ($oTenant && $oTenant->IsTwilioSupported())
			{
				$oTenant->TwilioAllow = CPost::Get('chAllowTwilio');
				$oTenant->TwilioPhoneNumber = CPost::Get('txtTwilioPhoneNumber');
				$oTenant->TwilioAccountSID = CPost::Get('txtTwilioAccountSID');
				$oTenant->TwilioAuthToken = CPost::Get('txtTwilioAuthToken');
				$oTenant->TwilioAppSID = CPost::Get('txtTwilioAppSID');
			}

			if ($oTenant && $oTenant->IsTwilioSupported() && $this->oModule->UpdateTenantAdminObject($oTenant))
			{
				$this->LastMessage = AP_LANG_SAVESUCCESSFUL;
				$this->LastError = '';
			}
			else
			{
				$this->LastMessage = '';
				$this->LastError = AP_LANG_SAVEUNSUCCESSFUL;
			}
		}
	}

	public function CommonSocial()
	{
		$oApiCapa = CApi::Manager('capability');
		/* @var $oApiCapa CApiCapabilityManager */

		if ($oApiCapa)
		{
			$oTenant = /* @var $oTenant CTenant */  $this->oModule->GetTenantAdminObject();
			if ($oTenant)
			{
				$oTenant->SocialFacebookAllow = CPost::Get('chSocialFacebookAllow');
				$oTenant->SocialFacebookId = CPost::Get('txtSocialFacebookId');
				$oTenant->SocialFacebookSecret = CPost::Get('txtSocialFacebookSecret');
				$oTenant->SocialGoogleAllow = CPost::Get('chSocialGoogleAllow');
				$oTenant->SocialGoogleId = CPost::Get('txtSocialGoogleId');
				$oTenant->SocialGoogleSecret = CPost::Get('txtSocialGoogleSecret');
				$oTenant->SocialTwitterAllow = CPost::Get('chSocialTwitterAllow');
				$oTenant->SocialTwitterId = CPost::Get('txtSocialTwitterId');
				$oTenant->SocialTwitterSecret = CPost::Get('txtSocialTwitterSecret');
			}

			if ($oTenant && $this->oModule->UpdateTenantAdminObject($oTenant))
			{
				$this->LastMessage = AP_LANG_SAVESUCCESSFUL;
				$this->LastError = '';
			}
			else
			{
				$this->LastMessage = '';
				$this->LastError = AP_LANG_SAVEUNSUCCESSFUL;
			}
		}
	}

	public function TenantsCollectionDelete()
	{
		$aCollection = CPost::Get('chCollection', array());
		$aAccountsIds = is_array($aCollection) ? $aCollection : array();

		$this->checkBolleanDeleteWithMessage(
			(0 < count($aAccountsIds) && $this->oModule->DeleteTenants($aAccountsIds))
		);
	}

	public function ChannelsCollectionDelete()
	{
		$aCollection = CPost::Get('chCollection', array());
		$aAccountsIds = is_array($aCollection) ? $aCollection : array();

		$this->checkBolleanDeleteWithMessage(
			(0 < count($aAccountsIds) && $this->oModule->DeleteChannels($aAccountsIds))
		);
	}

	public function UsersCollectionDelete()
	{
		$aCollection = CPost::Get('chCollection', array());
		$aAccountsIds = is_array($aCollection) ? $aCollection : array();

		$this->checkBolleanDeleteWithMessage(
			(0 < count($aAccountsIds) && $this->oModule->DeleteAccounts($aAccountsIds))
		);
	}

	public function UsersCollectionEnable()
	{
		$aCollection = CPost::Get('chCollection', array());
		$aAccountsIds = is_array($aCollection) ? $aCollection : array();
		if (0 < count($aAccountsIds))
		{
			$this->oModule->EnableAccounts($aAccountsIds, true);
		}
	}

	public function UsersCollectionDisable()
	{
		$aCollection = CPost::Get('chCollection', array());
		$aAccountsIds = is_array($aCollection) ? $aCollection : array();
		if (0 < count($aAccountsIds))
		{
			$this->oModule->EnableAccounts($aAccountsIds, false);
		}
	}

	public function DomainsCollectionDelete()
	{
		$aCollection = CPost::Get('chCollection', array());
		$aDomainsIds = is_array($aCollection) ? $aCollection : array();

		if (0 < count($aDomainsIds))
		{
			if (!$this->oModule->DeleteDomains($aDomainsIds))
			{
				$this->LastError = $this->oModule->GetLastErrorMessage();
			}
			else
			{
				$this->checkBolleanDeleteWithMessage(true);
			}
		}
		else
		{
			$this->checkBolleanDeleteWithMessage(false);
		}
	}

	public function SystemLicensing()
	{
		$sKey = CPost::Get('txtLicenseKey', null);
		if (null !== $sKey)
		{
			$this->checkBolleanWithMessage($this->oModule->UpdateLicenseKey(CPost::Get('txtLicenseKey')));
		}
	}

	public function CommonDav()
	{
		$bResult = false;

		$this->oSettings->SetConf('WebMail/ExternalHostNameOfDAVServer', CPost::Get('text_DAVUrl'));
		$this->oSettings->SetConf('WebMail/ExternalHostNameOfLocalImap', CPost::Get('text_IMAPHostName'));
		$this->oSettings->SetConf('WebMail/ExternalHostNameOfLocalSmtp', CPost::Get('text_SMTPHostName'));

		/* @var $oApiDavManager CApiDavManager */
		$oApiDavManager = CApi::Manager('dav');
		if ($oApiDavManager)
		{
			$bResult = $oApiDavManager->SetMobileSyncEnable(CPost::GetCheckBox('ch_EnableMobileSync'));
			$bResult &= $this->oSettings->SaveToXml();
		}

		$this->checkBolleanWithMessage((bool) $bResult);
	}
}