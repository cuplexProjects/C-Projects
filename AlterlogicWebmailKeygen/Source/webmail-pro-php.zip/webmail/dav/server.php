<?php

/*
 * Copyright (C) 2002-2013 AfterLogic Corp. (www.afterlogic.com)
 * Distributed under the terms of the license described in LICENSE
 *
 */

require_once dirname(__FILE__).'/../libraries/afterlogic/api.php';

/* Mapping PHP errors to exceptions */
function exception_error_handler($errno, $errstr, $errfile, $errline )
{
	throw new ErrorException($errstr, 0, $errno, $errfile, $errline);
}

set_error_handler('exception_error_handler');
@set_time_limit(3000);

//CApi::$bUseDbLog = false;

$server = new afterlogic\DAV\Server();
$server->exec();
